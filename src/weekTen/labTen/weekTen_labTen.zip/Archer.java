package weekTen.labTen;

public class Archer extends Character implements Fighter {
    private int agility;
    public Archer(String name, int health,int agility){
        super(name,health);
        this.agility = agility;
    }
    public int getAgility(){
        return agility;
    }
    public void setAgility(int agility){
        this.agility = agility;
    }
    public void attack(){
        System.out.println("Robin shoots an arrow! Agility: 50");
    }
    public void defend(){
        System.out.println("Robin doges the attack swiftly.");
    }

}
