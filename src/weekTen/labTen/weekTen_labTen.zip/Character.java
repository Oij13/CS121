package weekTen.labTen;

public abstract class Character {
    final public static int MAX_HEALTH = 100;

    protected String name;
    protected int health;

    public Character(String name, int health){
        this.name = name;

        this.health = Math.min(health,MAX_HEALTH);
    }
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name = name;
    }
    public int getHealth(){
        return health;
    }
    public void setHealth(int health){
        this.health = Math.max(0,Math.min(health,MAX_HEALTH));
    }
    public boolean isAlive(){
        if (health > 0){
        return true;
        }
        else {
            return false;
        }
    }
    public abstract void attack();
}
