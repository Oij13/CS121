package weekTen.labTen;

public interface Fighter {
    void attack();
    void defend();
}
