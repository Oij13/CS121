package weekSeven;

public class MovieSimulationTest {
    public static void main(String[] args) {
        MovieSimulationClass msc = new MovieSimulationClass();
        //int index = msc.selectMovie();
        msc.run();
    }
}
